#include<stdio.h>

int main(){
    printf("SP Assignment 7");
    return 0;
}